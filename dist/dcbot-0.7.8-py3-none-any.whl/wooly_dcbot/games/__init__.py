from . import hangman
from . import math_practice
from . import tictactoe
