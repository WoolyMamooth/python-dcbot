import hangman
import math_practice
import tictactoe
